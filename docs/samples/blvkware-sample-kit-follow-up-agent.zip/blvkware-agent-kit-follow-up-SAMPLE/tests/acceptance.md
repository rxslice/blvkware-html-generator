# Acceptance tests

Run each test against real examples from your business before the agent handles a real customer. A capability that fails its test stays switched off.

## 1. Booking

**Pass when:** Offered slots never conflict, never breach buffer rules, and land on the right calendar.

**Starts when:** a customer asks to book.

## 2. SMS

**Pass when:** A round-trip text conversation completes, and opt-outs are honoured immediately and permanently.

**Starts when:** a message arrives on SMS.

## 3. Quote follow-up

**Pass when:** A quote is chased on the agreed schedule, stops instantly on any reply, and records the reason it was lost.

**Starts when:** a quote is sent to a customer.

## 4. Interaction logging

**Pass when:** Every agent interaction appears on the correct record within a minute.

**Starts when:** a new contact or activity arrives.

## 5. CRM read and write

**Pass when:** Records created and updated by the agent match the field mapping exactly, with no orphan records.

**Starts when:** a new contact or activity arrives.
