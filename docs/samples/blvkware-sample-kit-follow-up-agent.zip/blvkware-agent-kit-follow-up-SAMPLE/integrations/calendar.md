# Calendar / scheduling

Works with systems such as Google Calendar, Outlook, Calendly, Cal.com.

**Why the agent needs it:** you listed it as a system the agent works with.

## What the agent does with it

**Reads** (always allowed):

- `calendar_list_events`: List events between two times.
- `calendar_free_slots`: Find open slots of a given length, honouring working hours and buffers.


**Reaches customers, suppliers or money** (held for a person at Draft):

- `calendar_create_event`: Book an event and invite the attendees.
- `calendar_update_event`: Move, change or cancel an event. Attendees are notified.

## Access to grant

Grant the smallest access that covers the list above: read access for the reads, write access only for the collections the agent changes. Give the agent its own login or API key, never a person's, so everything it does is attributable and can be revoked without locking anyone out.

## Also needed

- job durations, travel buffers and working hours

## Used by

- Booking
