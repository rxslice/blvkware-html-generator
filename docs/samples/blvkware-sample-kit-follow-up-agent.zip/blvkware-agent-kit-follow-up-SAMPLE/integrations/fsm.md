# Field service / jobs

Works with systems such as Jobber, ServiceTitan, Housecall Pro.

**Why the agent needs it:** you listed it as a system the agent works with.

## What the agent does with it

**Reads** (always allowed):

- `fsm_list_jobs`: List jobs in the field-service system.
- `fsm_get_job`: Read one job: customer, address, schedule, status and notes.

**Changes your own records** (allowed from Draft):

- `fsm_create_job`: Create a job request for the team to schedule.
- `fsm_update_job`: Update a job's status, notes or schedule fields.


## Access to grant

Grant the smallest access that covers the list above: read access for the reads, write access only for the collections the agent changes. Give the agent its own login or API key, never a person's, so everything it does is attributable and can be revoked without locking anyone out.

## Used by


