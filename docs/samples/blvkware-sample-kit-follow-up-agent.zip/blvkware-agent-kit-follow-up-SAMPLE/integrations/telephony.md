# Phone system

Works with systems such as RingCentral, Dialpad, Twilio, a plain mobile number.

**Why the agent needs it:** SMS depends on it.

## What the agent does with it

**Reads** (always allowed):

- `telephony_list_messages`: List recent text messages to or from a number.


**Reaches customers, suppliers or money** (held for a person at Draft):

- `telephony_send_sms`: Send a text message from the business number.
- `telephony_call`: Place an outbound call using an approved script.

## Access to grant

Grant the smallest access that covers the list above: read access for the reads, write access only for the collections the agent changes. Give the agent its own login or API key, never a person's, so everything it does is attributable and can be revoked without locking anyone out.

## Also needed

- job durations, travel buffers and working hours
- A2P 10DLC registration, which takes weeks and is outside anyone's control

## Used by

- Booking
- SMS
- Quote follow-up
