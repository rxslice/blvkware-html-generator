# CRM

Works with systems such as HubSpot, Pipedrive, Salesforce, Zoho, Go High Level.

**Why the agent needs it:** you listed it as a system the agent works with.

## What the agent does with it

**Reads** (always allowed):

- `crm_search`: Search CRM records.
- `crm_get`: Read one CRM record with its recent activity.

**Changes your own records** (allowed from Draft):

- `crm_create`: Create a CRM record.
- `crm_update`: Update fields on a CRM record.
- `crm_log_activity`: Record a note, call, email or meeting against a CRM record.


## Access to grant

Grant the smallest access that covers the list above: read access for the reads, write access only for the collections the agent changes. Give the agent its own login or API key, never a person's, so everything it does is attributable and can be revoked without locking anyone out.

## Also needed

- job durations, travel buffers and working hours
- field mapping to your CRM

## Used by

- Booking
- Quote follow-up
- Interaction logging
- CRM read and write
