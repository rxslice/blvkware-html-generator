# Email

Works with systems such as Google Workspace, Microsoft 365, Zoho.

**Why the agent needs it:** you listed it as a system the agent works with.

## What the agent does with it

**Reads** (always allowed):

- `email_search`: Search the mailbox. Returns message summaries, newest first.
- `email_get`: Read one message in full: headers, body and attachment names.

**Changes your own records** (allowed from Draft):

- `email_label`: Apply or remove labels (folders, categories) on a message.
- `email_draft`: Save a draft. Nothing is sent.

**Reaches customers, suppliers or money** (held for a person at Draft):

- `email_send`: Send an email, or send a saved draft.

## Access to grant

Grant the smallest access that covers the list above: read access for the reads, write access only for the collections the agent changes. Give the agent its own login or API key, never a person's, so everything it does is attributable and can be revoked without locking anyone out.

## Also needed

- job durations, travel buffers and working hours

## Used by

- Booking
- Quote follow-up
