# Before you switch it on

The kit contains behaviour, not facts about your business. Everything below is a fact only you can supply. Fill each one into the setting it names (in `workflows/`) before the agent runs.

## Settings to fill in

- **Booking** `durations`: how long each kind of job takes.
- **Booking** `buffer_minutes`: travel or preparation time between bookings.
- **Booking** `working_hours`: when bookings are allowed.
- **SMS** `business_number`: the business number the agent uses.
- **Interaction logging** `field_mapping`: which CRM field each value belongs in.
- **CRM read and write** `field_mapping`: which CRM field each value belongs in.

## What each capability needs from you

- **Booking**: job durations, travel buffers and working hours.
- **SMS**: A2P 10DLC registration, which takes weeks and is outside anyone's control.
- **CRM read and write**: field mapping to your CRM.

## Access to your systems

- **Email**: see `integrations/email.md`.
- **CRM**: see `integrations/crm.md`.
- **Calendar / scheduling**: see `integrations/calendar.md`.
- **Field service / jobs**: see `integrations/fsm.md`.
- **Phone system**: see `integrations/telephony.md`.

## Outside anyone's control

- Texting your customers from a US business number requires A2P 10DLC registration with the carriers. Part of it is a manual review that nobody can hurry, so budget weeks rather than days. Build and test everything else meanwhile, and switch SMS on when the registration clears.
