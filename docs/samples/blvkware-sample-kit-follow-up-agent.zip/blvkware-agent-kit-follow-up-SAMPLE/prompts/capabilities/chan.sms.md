# SMS

Texts your customers from a business number and acts on what they text back.

**Starts when:** a message arrives on SMS (event).

## Procedure

1. Hand each message to the capability that owns it; SMS is transport, not judgment.
2. Honour an opt-out word immediately and permanently (agent_suppress), and confirm it once.
3. Never send between 21:00 and 08:00 in the recipient's time zone. A step that falls inside quiet hours waits for the next allowed time and is not skipped.
4. Every outbound message is external: held at Draft.

## Hand to a person when

- Someone asks for a person.
- A message looks like a complaint or an emergency.

## Tools

- `telephony_list_messages`
- `telephony_send_sms`
- `telephony_call`
- `agent_suppress`
- `agent_is_suppressed`
- `agent_log`

## Settings

See `workflows/chan.sms.json` for the machine-readable version.

- `category`: `"telephony"`
- `channel`: `"sms"`
- `business_number`: **to fill in**: the business number the agent uses
- `opt_out_words`: `["STOP","UNSUBSCRIBE","END","QUIT","CANCEL"]`

## Before you switch it on

- A2P 10DLC registration, which takes weeks and is outside anyone's control

## Outside anyone's control

Texting your customers from a US business number requires A2P 10DLC registration with the carriers. Part of it is a manual review that nobody can hurry, so budget weeks rather than days. Build and test everything else meanwhile, and switch SMS on when the registration clears.

## Acceptance test

A round-trip text conversation completes, and opt-outs are honoured immediately and permanently.
