# Booking

Offers real slots that respect travel time and job length, then books them.

**Starts when:** a customer asks to book (event).

## Procedure

1. Find slots that fit the job's duration and buffers (calendar_free_slots).
2. Offer two or three; confirm one; book it.
3. Booking sends an invitation, so it is external: held at Draft.

## Hand to a person when

- No slot fits in the next two weeks.
- The request is outside what the business does.

## Tools

- `calendar_free_slots`
- `calendar_create_event`
- `crm_search`
- `email_draft`
- `email_send`
- `telephony_send_sms`
- `agent_request_approval`
- `agent_log`

## Settings

See `workflows/appt.book.json` for the machine-readable version.

- `durations`: **to fill in**: how long each kind of job takes
- `buffer_minutes`: **to fill in**: travel or preparation time between bookings
- `working_hours`: **to fill in**: when bookings are allowed

## Before you switch it on

- Job durations, travel buffers and working hours

## Acceptance test

Offered slots never conflict, never breach buffer rules, and land on the right calendar.
