# CRM read and write

Reads and updates your CRM itself, so records are right without anyone typing.

**Starts when:** a new contact or activity arrives (event).

## Procedure

1. Look the record up first (crm_search) by email, then phone. Update it if it exists; create it only if it does not.
2. Never create a duplicate. Two records for one person is the failure this capability exists to prevent.
3. Write the source of every value you set, so a person can see where it came from.

## Hand to a person when

- Two records disagree and neither is clearly right.

## Tools

- `crm_search`
- `crm_get`
- `crm_create`
- `crm_update`
- `crm_log_activity`
- `agent_log`

## Settings

See `workflows/crm.sync.json` for the machine-readable version.

- `category`: `"crm"`
- `collection`: `"contacts"`
- `mode`: `"sync"`
- `field_mapping`: **to fill in**: which CRM field each value belongs in

## Before you switch it on

- Field mapping to your CRM

## Acceptance test

Records created and updated by the agent match the field mapping exactly, with no orphan records.
