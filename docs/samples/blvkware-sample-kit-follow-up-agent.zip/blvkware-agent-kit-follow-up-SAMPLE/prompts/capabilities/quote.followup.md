# Quote follow-up

Chases every quote until the customer answers one way or the other, then stops.

**Starts when:** a quote is sent to a customer (event).

## Procedure

1. Enrol the record when a quote is sent to a customer. One enrolment per record: enrolling twice does nothing.
2. Step 1, day 2: a short, friendly nudge about the quote.
3. Step 2, day 5: a more direct follow-up asking for a decision either way.
4. Step 3, day 10: a final message that makes declining easy.
5. Before every step, check the contact is not suppressed (agent_is_suppressed). A suppressed contact stops the sequence for good.
6. Write each message for its purpose, to the customer who received the quote. Use only facts from the record, the conversation or the knowledge base. Never state a price, date, policy or promise that is not written down there.
7. Sending is external: at Draft (L1) the message is held with agent_request_approval; the step counts as done only when it is sent.
8. Never send between 21:00 and 08:00 in the recipient's time zone. A step that falls inside quiet hours waits for the next allowed time and is not skipped.
9. Stop as soon as the quote is accepted or declined, or the customer replies. Record the stop reason on the enrolment.

## Hand to a person when

- The contact replies angrily, disputes something, or asks for a person.
- A step fails to send twice.

## Tools

- `agent_is_suppressed`
- `agent_schedule`
- `email_draft`
- `email_send`
- `telephony_send_sms`
- `agent_request_approval`
- `crm_get`
- `crm_update`
- `crm_log_activity`
- `agent_log`

## Settings

See `workflows/quote.followup.json` for the machine-readable version.

- `steps`: `[[2,"a short, friendly nudge about the quote"],[5,"a more direct follow-up asking for a decision either way"],[10,"a final message that makes declining easy"]]`
- `subject`: `"Following up on your quote"`
- `quiet_hours`: `{"from":"21:00","to":"08:00","timezone":"recipient"}`

## Acceptance test

A quote is chased on the agreed schedule, stops instantly on any reply, and records the reason it was lost.
