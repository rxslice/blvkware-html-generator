"""Your systems, one function per tool.

Fill in each function with a call to your own system and return what it
returns (a dict is best). Each docstring lists the inputs the model will send.
Until a function is filled in it raises, the runtime reports the call as
failed, and the model is told it did not happen: nothing can pretend to work.

Keep credentials out of this file: read them from environment variables or
your secret store. The runtime has already checked the autonomy level,
approvals, opt-outs and quiet hours before any of these run.

    from handlers import register_all
    register_all(rt)
"""
from __future__ import annotations

import os  # noqa: F401  (for credentials from the environment)


# ---- Email -----------------------------------------------------------------

def email_search(args: dict):
    """Search the mailbox. Returns message summaries, newest first. [read]

    args:
        query (string, required): Search text, sender or subject.
        folder (string): Folder or label to search, e.g. INBOX.
        since (string): Only messages received after this time.
        limit (integer): Maximum results to return.
    """
    raise NotImplementedError("email_search: call your email here")


def email_get(args: dict):
    """Read one message in full: headers, body and attachment names. [read]

    args:
        message_id (string, required): The message identifier returned by email_search.
    """
    raise NotImplementedError("email_get: call your email here")


def email_label(args: dict):
    """Apply or remove labels (folders, categories) on a message. [internal]

    args:
        message_id (string, required): The message to label.
        add (array): Labels to add.
        remove (array): Labels to remove.
    """
    raise NotImplementedError("email_label: call your email here")


def email_draft(args: dict):
    """Save a draft. Nothing is sent. [internal]

    args:
        to (array, required): Recipients.
        subject (string, required): Subject line.
        body (string, required): Plain-text body.
        reply_to_message_id (string): Message being answered, to keep the thread.
    """
    raise NotImplementedError("email_draft: call your email here")


def email_send(args: dict):
    """Send an email, or send a saved draft. [external]

    args:
        draft_id (string): A draft saved by email_draft.
        to (array): Recipients, when not sending a draft.
        subject (string): Subject, when not sending a draft.
        body (string): Body, when not sending a draft.
        reply_to_message_id (string): Message being answered.
    """
    raise NotImplementedError("email_send: call your email here")


# ---- Calendar / scheduling -------------------------------------------------

def calendar_list_events(args: dict):
    """List events between two times. [read]

    args:
        start (string, required): Window start.
        end (string, required): Window end.
        calendar_id (string): Which calendar. Defaults to the primary one.
    """
    raise NotImplementedError("calendar_list_events: call your calendar / scheduling here")


def calendar_free_slots(args: dict):
    """Find open slots of a given length, honouring working hours and buffers. [read]

    args:
        duration_minutes (integer, required): Length of the slot.
        window_start (string, required): Search from.
        window_end (string, required): Search until.
        buffer_minutes (integer): Gap to keep before and after.
    """
    raise NotImplementedError("calendar_free_slots: call your calendar / scheduling here")


def calendar_create_event(args: dict):
    """Book an event and invite the attendees. [external]

    args:
        title (string, required): Event title.
        start (string, required): Start.
        end (string, required): End.
        attendees (array): Who to invite.
        location (string): Address or meeting link.
        notes (string): Details for the attendees.
    """
    raise NotImplementedError("calendar_create_event: call your calendar / scheduling here")


def calendar_update_event(args: dict):
    """Move, change or cancel an event. Attendees are notified. [external]

    args:
        event_id (string, required): The event.
        start (string): New start.
        end (string): New end.
        status (string): confirmed or cancelled.
        notes (string): Updated details.
    """
    raise NotImplementedError("calendar_update_event: call your calendar / scheduling here")


# ---- CRM -------------------------------------------------------------------

def crm_search(args: dict):
    """Search CRM records. [read]

    args:
        object (string, required): Record type.
        query (string, required): Name, email, phone or free text.
        limit (integer): Maximum results to return.
    """
    raise NotImplementedError("crm_search: call your CRM here")


def crm_get(args: dict):
    """Read one CRM record with its recent activity. [read]

    args:
        object (string, required): Record type.
        id (string, required): Record identifier.
    """
    raise NotImplementedError("crm_get: call your CRM here")


def crm_create(args: dict):
    """Create a CRM record. [internal]

    args:
        object (string, required): Record type.
        fields (object, required): Field values, using the CRM's own field names.
    """
    raise NotImplementedError("crm_create: call your CRM here")


def crm_update(args: dict):
    """Update fields on a CRM record. [internal]

    args:
        object (string, required): Record type.
        id (string, required): Record identifier.
        fields (object, required): Only the fields that change.
    """
    raise NotImplementedError("crm_update: call your CRM here")


def crm_log_activity(args: dict):
    """Record a note, call, email or meeting against a CRM record. [internal]

    args:
        object (string, required): Record type.
        id (string, required): Record identifier.
        type (string, required): Activity type.
        summary (string, required): What happened.
        occurred_at (string): When it happened.
    """
    raise NotImplementedError("crm_log_activity: call your CRM here")


# ---- Field service / jobs --------------------------------------------------

def fsm_list_jobs(args: dict):
    """List jobs in the field-service system. [read]

    args:
        status (string): Job status to filter on.
        from (string): Scheduled after.
        to (string): Scheduled before.
        limit (integer): Maximum results to return.
    """
    raise NotImplementedError("fsm_list_jobs: call your field service / jobs here")


def fsm_get_job(args: dict):
    """Read one job: customer, address, schedule, status and notes. [read]

    args:
        job_id (string, required): Job identifier.
    """
    raise NotImplementedError("fsm_get_job: call your field service / jobs here")


def fsm_create_job(args: dict):
    """Create a job request for the team to schedule. [internal]

    args:
        customer (string, required): Customer name or identifier.
        description (string, required): What the job is.
        address (string): Where.
        requested_date (string): When the customer asked for.
    """
    raise NotImplementedError("fsm_create_job: call your field service / jobs here")


def fsm_update_job(args: dict):
    """Update a job's status, notes or schedule fields. [internal]

    args:
        job_id (string, required): Job identifier.
        fields (object, required): Only the fields that change.
    """
    raise NotImplementedError("fsm_update_job: call your field service / jobs here")


# ---- Phone system ----------------------------------------------------------

def telephony_list_messages(args: dict):
    """List recent text messages to or from a number. [read]

    args:
        number (string): Phone number in E.164 form.
        since (string): After this time.
        limit (integer): Maximum results to return.
    """
    raise NotImplementedError("telephony_list_messages: call your phone system here")


def telephony_send_sms(args: dict):
    """Send a text message from the business number. [external]

    args:
        to (string, required): Phone number in E.164 form.
        body (string, required): Message text.
    """
    raise NotImplementedError("telephony_send_sms: call your phone system here")


def telephony_call(args: dict):
    """Place an outbound call using an approved script. [external]

    args:
        to (string, required): Phone number in E.164 form.
        script (string, required): Which approved script to use.
        purpose (string): Why the call is being made.
    """
    raise NotImplementedError("telephony_call: call your phone system here")



HANDLERS = {"email_search": email_search, "email_get": email_get, "email_label": email_label, "email_draft": email_draft, "email_send": email_send, "calendar_list_events": calendar_list_events, "calendar_free_slots": calendar_free_slots, "calendar_create_event": calendar_create_event, "calendar_update_event": calendar_update_event, "crm_search": crm_search, "crm_get": crm_get, "crm_create": crm_create, "crm_update": crm_update, "crm_log_activity": crm_log_activity, "fsm_list_jobs": fsm_list_jobs, "fsm_get_job": fsm_get_job, "fsm_create_job": fsm_create_job, "fsm_update_job": fsm_update_job, "telephony_list_messages": telephony_list_messages, "telephony_send_sms": telephony_send_sms, "telephony_call": telephony_call}


def register_all(rt) -> None:
    """Register every handler above with a Runtime."""
    for name, fn in HANDLERS.items():
        if name in rt.tools:
            rt.register(name, fn)
