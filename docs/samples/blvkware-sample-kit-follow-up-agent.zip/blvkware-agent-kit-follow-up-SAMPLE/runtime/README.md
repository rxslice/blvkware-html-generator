# The runtime: your agent's rules, enforced in code

A prompt is advice. This folder is the part that makes the rules hold even when
the model gets it wrong. Put it between your model and your systems and every
tool call is checked before anything happens.

| File | What it does |
| --- | --- |
| `blvk_runtime.py` | The gate. Checks each call against your autonomy level, holds actions for approval, keeps the audit log, honours opt-outs, quiet hours and the money limit. Also the approvals command line. |
| `handlers.py` | One function per tool in this kit, each documented with its inputs. Fill in the bodies with calls to your systems. Unfilled ones fail safely. |
| `dashboard.py` | The approvals page: approve, edit or reject what is waiting, see what was handed to a person, manage opt-outs, read the log. |
| `guards.py` | Checks each customer message for injected instructions, opt-outs and requests for a person, and each draft for prices, dates and your own "never do" rules. |
| `test_runtime.py` | Tests that prove the rules hold for this kit's tools. Run them before you trust it. |
| `example_anthropic.py`, `example_openai.py` | The full loop with each provider, about 50 lines each. |
| `config.json` | Your time zone, quiet hours and guard thresholds. |

Plain Python 3.9+, standard library only. No account, no server, no keys in any file.

## Five minutes to a working gate

```
python -m unittest runtime/test_runtime.py -v     # every rule, tested against this kit
python runtime/blvk_runtime.py status
```

Then, in your own code:

```python
from blvk_runtime import Runtime

from handlers import register_all

rt = Runtime()                                   # reads this kit's policy files
register_all(rt)                                 # your systems, from handlers.py

result = rt.call(tool_name, tool_input)          # what your loop does for every tool call
result.status    # done | held | deferred | refused | failed
result.for_model()                               # the tool result to give back to the model
```

Every minute or so, call `rt.run_due()`: it carries out actions a person has
approved and sends that were waiting for quiet hours to end.

## What happens to each kind of call

| Effect | L0 Watch | L1 Draft | L2 Approve | L3 Operate |
| --- | --- | --- | --- | --- |
| read | runs | runs | runs | runs |
| internal (your own records) | refused | runs | runs | runs |
| external (customers, suppliers, money) | refused | held for a person | runs below the money limit, else held | runs |

On top of that, at every level: a contact who opted out is never contacted, a
customer-facing send at night waits until morning, and a draft the outbound
check flags is held for a person even at L3.

## Approving things

The easy way is the approvals page:

```
python runtime/dashboard.py        then open the address it prints
```

It runs on your own computer only, and every change needs the secret in that
address. Or from the command line:

```
python runtime/blvk_runtime.py approvals
python runtime/blvk_runtime.py approve appr_1a2b3c --by Sam
python runtime/blvk_runtime.py reject appr_1a2b3c --by Sam --note "wrong price"
python runtime/blvk_runtime.py verify-log
```

Everything lives in `state/` (or `BLVK_STATE`): `approvals/`, `audit.jsonl`,
`suppressed.json`, `escalations.jsonl`, `scheduled.json`. Plain JSON, readable
by a person and by anything you build on top (a Slack button, a small web page).

## The guards and Laya

The rules layer always runs. For better judgement, install Laya, an open decision
model (Apache 2.0) that runs on your own machine at no per-message cost:

```
pip install laya          (and a CPU or GPU build of torch)
```

With it, the guards also check each draft against every "never do" rule you
wrote, and catch softer opt-outs ("please don't reach out again") and requests
for a person that no keyword list would. Measured zero-shot before shipping:
36 of 40 right on rule checks, 36 of 36 on customer messages. About 1 to 3
seconds per message on a CPU, milliseconds on a GPU. A flag means "a person
should look", never "this is certainly wrong", and no flag is not a guarantee:
keep the agent at Draft until its tests pass on your own real messages.

## Settings

`config.json`, or environment variables that override it:
`BLVK_TIMEZONE` (IANA name, e.g. America/Chicago; on Windows also `pip install tzdata`),
`BLVK_LEVEL`, `BLVK_MONEY_LIMIT`, `BLVK_STATE`, `BLVK_GUARD` (`rules` to skip Laya).
