"""The approvals page: a small local web page for the person who decides.

    python runtime/dashboard.py            then open the address it prints

It shows what is waiting for approval (with Approve, Edit and Reject), what
the agent handed to a person, who has opted out, and the audit log with its
integrity check. Standard library only.

It listens on 127.0.0.1 only, and every change needs the secret in the address
it prints, so another web page open in the same browser cannot approve things
behind your back. Decisions are carried out by your agent process on its next
Runtime.run_due(), with your handlers, at an allowed hour.
"""
from __future__ import annotations

import argparse
import html
import json
import secrets
import sys
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

sys.path.insert(0, str(Path(__file__).resolve().parent))
from blvk_runtime import Runtime, RuntimeError_  # noqa: E402

CSS = """
:root{--bg:#0A0908;--card:#15120E;--line:rgba(245,240,230,.12);--ink:#F5F0E6;--ink2:#B3A894;--ink3:#8a806f;--ok:#D4F24A;--warn:#E8734A;--brass:#D9B65C}
@media (prefers-color-scheme: light){:root{--bg:#f6f3ec;--card:#fff;--line:rgba(0,0,0,.12);--ink:#16130f;--ink2:#4d463b;--ink3:#6d655a;--ok:#4a6b00;--warn:#b04a1f;--brass:#8a6a1a}}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:15px/1.5 system-ui,-apple-system,Segoe UI,sans-serif}
main{max-width:980px;margin:0 auto;padding:24px 16px 64px}h1{font-size:22px;margin:0 0 4px}h2{font-size:16px;margin:32px 0 10px;color:var(--ink2);text-transform:uppercase;letter-spacing:.08em}
.sub{color:var(--ink2);margin:0 0 20px}.card{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:16px;margin:0 0 12px}
.row{display:flex;gap:10px;align-items:baseline;flex-wrap:wrap}.tool{font-family:ui-monospace,Consolas,monospace;font-weight:700}
.muted{color:var(--ink3);font-size:13px}.flag{color:var(--warn);font-weight:600;font-size:14px;margin:6px 0 0}
pre,textarea{font:13px/1.45 ui-monospace,Consolas,monospace;background:var(--bg);color:var(--ink);border:1px solid var(--line);border-radius:8px;padding:10px;width:100%;white-space:pre-wrap;word-break:break-word;margin:10px 0}
textarea{min-height:120px}input[type=text]{background:var(--bg);color:var(--ink);border:1px solid var(--line);border-radius:8px;padding:8px 10px;min-width:220px;flex:1}
button{font:inherit;font-weight:700;border-radius:8px;border:1px solid var(--line);padding:8px 14px;cursor:pointer;background:transparent;color:var(--ink)}
button.ok{background:var(--ok);color:#15170A;border-color:transparent}button.no{color:var(--warn)}
.pill{display:inline-block;border-radius:999px;padding:2px 10px;font-size:12px;font-weight:700;border:1px solid var(--line)}
.good{color:var(--ok)}.bad{color:var(--warn)}table{width:100%;border-collapse:collapse;font-size:13px}td{border-top:1px solid var(--line);padding:6px 8px;vertical-align:top}
details summary{cursor:pointer;color:var(--ink2);font-weight:600}
"""


def esc(v) -> str:
    return html.escape(str(v), quote=True)


def when(v) -> str:
    """2026-09-27T05:22:44Z -> 2026-09-27 05:22 UTC"""
    s = str(v or "")
    return esc(s[:16].replace("T", " ") + " UTC") if len(s) >= 16 and s.endswith("Z") else esc(s)


class Dashboard:
    def __init__(self, rt: Runtime, token: str | None = None):
        self.rt = rt
        self.token = token or secrets.token_urlsafe(18)
        self.lock = threading.Lock()

    # ---- pages ----------------------------------------------------------------

    def page(self, notice: str = "") -> str:
        rt, t = self.rt, esc(self.token)
        ok, why = rt.verify_log()
        pending = rt.approvals()
        parts = [f"<h1>{esc(rt.manifest.get('role', {}).get('name', 'Agent'))}: approvals</h1>",
                 f"<p class='sub'>Autonomy level <b>{esc(rt.level)}</b> · {len(pending)} waiting · "
                 f"audit log <span class='{'good' if ok else 'bad'}'>{esc(why)}</span></p>"]
        if notice:
            parts.append(f"<div class='card'><b>{esc(notice)}</b></div>")
        for w in rt.warnings:
            parts.append(f"<div class='card muted'>{esc(w)}</div>")

        parts.append("<h2>Waiting for you</h2>")
        if not pending:
            parts.append("<p class='muted'>Nothing is waiting.</p>")
        for a in pending:
            aid = esc(a["id"])
            flags = "".join(f"<p class='flag'>Check: {esc(f)}</p>" for f in a.get("flags", []))
            body = json.dumps(a["input"], indent=2, ensure_ascii=False)
            parts.append(f"""<div class="card"><div class="row"><span class="tool">{esc(a['action'])}</span>
<span class="muted">{when(a['requested_at'])}{(' · ' + esc(a['record_ref'])) if a.get('record_ref') else ''}</span></div>
<p>{esc(a.get('why', ''))}</p>{flags}<pre>{esc(body)}</pre>
<form method="post" action="/decide?t={t}" class="row">
<input type="hidden" name="id" value="{aid}"><input type="text" name="by" placeholder="Your name" required>
<input type="text" name="note" placeholder="Note (optional)">
<button class="ok" name="decision" value="approved">Approve</button><button class="no" name="decision" value="rejected">Reject</button></form>
<details><summary>Edit before approving</summary><form method="post" action="/decide?t={t}">
<input type="hidden" name="id" value="{aid}"><input type="hidden" name="decision" value="edited">
<textarea name="input">{esc(body)}</textarea><div class="row"><input type="text" name="by" placeholder="Your name" required>
<button class="ok">Approve with these changes</button></div></form></details></div>""")

        handled = set(rt.store.read_json("escalations_handled.json", []))
        esc_items = [e for e in rt.store.lines("escalations.jsonl") if e.get("id") not in handled][-20:][::-1]
        parts.append("<h2>Handed to a person</h2>")
        if not esc_items:
            parts.append("<p class='muted'>Nothing handed over.</p>")
        for e in esc_items:
            parts.append(f"<div class='card'><div class='row'><span class='pill'>{esc(e.get('urgency', ''))}</span>"
                         f"<b>{esc(e.get('reason', ''))}</b><span class='muted'>{when(e.get('at', ''))}</span></div>"
                         f"<p>{esc(e.get('summary', ''))}</p>"
                         f"<form method='post' action='/handled?t={t}' class='row'><input type='hidden' name='id' value='{esc(e.get('id', ''))}'>"
                         f"<input type='text' name='by' placeholder='Your name' required><button>Mark handled</button></form></div>")

        sup = rt.suppressed()
        parts.append("<h2>Do not contact</h2>")
        parts.append(f"""<form method="post" action="/suppress?t={t}" class="card row">
<input type="text" name="contact" placeholder="Email or phone number" required><input type="text" name="reason" placeholder="Why" required>
<button>Add</button></form>""")
        if sup:
            rows = "".join(f"<tr><td>{esc(k)}</td><td>{esc(v.get('reason', ''))}</td><td class='muted'>{esc(v.get('by', ''))} {when(v.get('at', ''))}</td></tr>"
                           for k, v in sorted(sup.items()))
            parts.append(f"<div class='card'><table>{rows}</table></div>")

        log = rt.store.lines("audit.jsonl")[-50:][::-1]
        parts.append("<h2>Audit log (latest 50)</h2>")
        rows = "".join(f"<tr><td class='muted'>{when(e['at'])}</td><td>{esc(e['event'])}</td><td>{esc(e['outcome'])}</td>"
                       f"<td class='muted'>{esc(e.get('source', ''))}</td></tr>" for e in log)
        parts.append(f"<div class='card'><table>{rows or '<tr><td>Empty.</td></tr>'}</table></div>")
        return ("<!doctype html><html lang='en'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>"
                f"<title>Approvals</title><style>{CSS}</style></head><body><main>{''.join(parts)}</main></body></html>")

    # ---- actions ---------------------------------------------------------------

    def decide(self, form: dict) -> str:
        aid, decision, by = form.get("id", ""), form.get("decision", ""), form.get("by", "").strip()
        if not by:
            return "Add your name so the log shows who decided."
        edited = None
        if decision == "edited":
            try:
                edited = json.loads(form.get("input", ""))
            except json.JSONDecodeError as exc:
                return f"That is not valid JSON: {exc}"
        try:
            a = self.rt.decide_approval(aid, decision, by, form.get("note", ""), edited_input=edited)
        except RuntimeError_ as exc:
            return str(exc)
        return f"{a['action']} {a['decision']} by {by}." + ("" if a["decision"] == "rejected" else " Your agent carries it out on its next run.")

    def suppress(self, form: dict) -> str:
        contact, reason = form.get("contact", "").strip(), form.get("reason", "").strip()
        if not contact or not reason:
            return "Both the contact and the reason are needed."
        self.rt.suppress(contact, reason, by="person")
        self.rt.log(f"suppressed {contact} by a person", "done", source="person", detail={"reason": reason})
        return f"{contact} will not be contacted."

    def handled(self, form: dict) -> str:
        eid, by = form.get("id", ""), form.get("by", "").strip()
        known = {e.get("id") for e in self.rt.store.lines("escalations.jsonl")}
        if eid not in known:
            return "That escalation does not exist."
        if not by:
            return "Add your name so the log shows who handled it."
        done = self.rt.store.read_json("escalations_handled.json", [])
        if eid not in done:
            self.rt.store.write_json("escalations_handled.json", done + [eid])
            self.rt.log(f"escalation {eid} handled by {by}", "done", source="person", detail={"escalation": eid, "by": by})
        return "Marked as handled."

    def handler_class(self):
        dash = self

        class H(BaseHTTPRequestHandler):
            def log_message(self, *args):  # quiet
                pass

            def _send(self, code: int, body: str, ctype="text/html; charset=utf-8"):
                data = body.encode("utf-8")
                self.send_response(code)
                self.send_header("Content-Type", ctype)
                self.send_header("Content-Length", str(len(data)))
                self.send_header("Cache-Control", "no-store")
                self.send_header("X-Frame-Options", "DENY")
                self.send_header("Content-Security-Policy", "default-src 'none'; style-src 'unsafe-inline'; form-action 'self'")
                self.end_headers()
                self.wfile.write(data)

            def _authorised(self) -> bool:
                q = parse_qs(urlparse(self.path).query)
                return secrets.compare_digest((q.get("t") or [""])[0], dash.token)

            def do_GET(self):
                if urlparse(self.path).path != "/" or not self._authorised():
                    return self._send(403, "Open the address the dashboard printed, including its ?t= part.", "text/plain; charset=utf-8")
                self._send(200, dash.page())

            def do_POST(self):
                path = urlparse(self.path).path
                if not self._authorised() or path not in ("/decide", "/suppress", "/handled"):
                    return self._send(403, "Not allowed.", "text/plain; charset=utf-8")
                n = min(int(self.headers.get("Content-Length") or 0), 200_000)
                form = {k: v[0] for k, v in parse_qs(self.rfile.read(n).decode("utf-8")).items()}
                with dash.lock:
                    notice = {"/decide": dash.decide, "/suppress": dash.suppress, "/handled": dash.handled}[path](form)
                self._send(200, dash.page(notice))

        return H

    def serve(self, port: int = 8765) -> ThreadingHTTPServer:
        return ThreadingHTTPServer(("127.0.0.1", port), self.handler_class())


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Local approvals page for this agent.")
    ap.add_argument("--port", type=int, default=8765)
    ap.add_argument("--state", help="state folder (default: <kit>/state or $BLVK_STATE)")
    a = ap.parse_args(argv)
    dash = Dashboard(Runtime(state=a.state, guard=None))
    server = dash.serve(a.port)
    print(f"Approvals page: http://127.0.0.1:{server.server_address[1]}/?t={dash.token}")
    print("Keep this address private. Ctrl+C to stop.")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    return 0


if __name__ == "__main__":
    sys.exit(main())
