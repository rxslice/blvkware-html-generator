"""Guards: fast checks on what comes in and what goes out.

Two layers, combined so either one can raise a flag:

  1. Rules (always on, no install): patterns for injected instructions,
     explicit opt-outs, requests for a person, and drafts that name a price, a
     discount, a refund, a date or a time.
  2. Laya (optional): an open, local decision model (Apache 2.0) that answers the
     questions in guards/checks.json with calibrated probabilities, including one
     question per "never do" rule the owner wrote. No text is generated and
     nothing leaves the machine.

         pip install laya          # plus a CPU or GPU build of torch
         set BLVK_GUARD=rules      # to force the rules layer only

     python runtime/guards.py in  "text"        check one customer message
     python runtime/guards.py out "text"        check one draft
     python runtime/guards.py eval mine.jsonl   score it on your own labelled examples

The guard never acts on its own. It returns flags; the runtime turns an outbound
flag into a hold for a person, and an inbound flag into advice for the model.
Only an explicit "STOP"-style opt-out is recorded automatically, because it is
unambiguous and the safe direction is to stop.

Measured before shipping (zero-shot Laya on a CPU, small hand-labelled sets,
2026-09-26): the owner's rules asked about each draft, 36 of 40 right at the 0.5
threshold (2 false alarms, 2 misses); opt-out, wants-a-person and upset on
customer messages, 36 of 36 at 0.7. About 1 to 3 s per message on a CPU,
milliseconds on a GPU. Laya alone missed some injection wording, which is why
the rules layer always runs as well. A flag means "a person should look"; no
flag is not a guarantee.
"""
from __future__ import annotations

import json
import os
import re
from pathlib import Path
from typing import Optional

# ---- rules --------------------------------------------------------------------------

INJECTION = [
    r"\bignore (all |any |the |your )?(previous|prior|above|earlier|former) (instructions|rules|prompts?|messages?)",
    r"\b(disregard|forget|override|bypass) (all |any |the |your )?(previous |prior )?(instructions|rules|guardrails|policy|policies|prompt)",
    r"\b(system|developer) prompt\b", r"\byour (instructions|prompt|rules) (are|say)\b",
    r"\b(print|reveal|show|repeat|output|give me) (me )?(your|the) (full |entire |hidden )?(system prompt|instructions|prompt|rules|configuration)",
    r"\b(api|secret|access) ?keys?\b", r"\bpasswords?\b.*\b(send|give|share|list)\b",
    r"\byou are (now|no longer)\b", r"\b(admin|developer|debug|god|jailbreak|dan) mode\b",
    r"^\s*(system|assistant)\s*:", r"\bnew (policy|instructions?) from\b",
    r"\bpretend (that )?(the )?(approval|check|step)", r"\bact as (if|though)\b",
    r"\b(forward|send|export|email) (all|every|the whole|each) (emails?|messages?|records?|contacts?|customers?|inbox)",
    r"\b(mark|set) all\b.*\b(paid|approved|resolved|closed)\b",
]
OPT_OUT_EXPLICIT = [
    r"^\s*(stop|stopall|unsubscribe|end|quit|cancel|optout|opt out|remove me)\s*[.!]*\s*$",
    r"\b(unsubscribe|opt me out|remove me from (your|the|this) (list|mailing))\b",
    r"\bstop (texting|emailing|messaging|contacting|calling) me\b",
    r"\b(do not|don't|never) (text|email|message|contact|call) me\b",
]
WANTS_PERSON = [
    r"\b(speak|talk|chat) (to|with) (a |an |the |someone|somebody|real)?\s*(person|human|manager|owner|someone|somebody|representative|agent)\b",
    r"\b(real|actual) (person|human)\b", r"\bare you (a )?(bot|robot|machine|ai|real)\b", r"\bcall me\b",
]
UPSET = [r"\b(furious|unacceptable|ridiculous|disgusting|scam|lawyer|sue|refund now|terrible|worst)\b", r"!!+"]
COMMITMENT = [
    r"[$£€]\s?\d", r"\b\d+(\.\d+)?\s?(dollars|usd|bucks)\b", r"\b\d{1,3}\s?%\s?(off|discount)\b",
    r"\b(discount|refund|credit|free of charge|no charge|won't be charged|will not be charged|waive[ds]?|price match|match (that|their|the) (price|quote))\b",
    r"\b\d{1,2}(:\d{2})?\s?(am|pm)\b", r"\b(mon|tues|wednes|thurs|fri|satur|sun)day\b",
    r"\b(today|tonight|tomorrow|this (morning|afternoon|evening|week))\b",
    r"\b(jan(uary)?|feb(ruary)?|mar(ch)?|apr(il)?|may|jun(e)?|jul(y)?|aug(ust)?|sep(t(ember)?)?|oct(ober)?|nov(ember)?|dec(ember)?)\.? \d{1,2}(st|nd|rd|th)?\b",
    r"\b\d{1,2}/\d{1,2}(/\d{2,4})?\b", r"\b(guarantee[ds]?|promise[ds]?|confirmed for|booked (you )?(in|for))\b",
    r"\b(within|in) \d+ (hours?|days?|minutes?)\b",
]


def _any(patterns, text: str) -> list[str]:
    t = text.lower()
    return [p for p in patterns if re.search(p, t, re.MULTILINE)]


class Guard:
    def __init__(self, checks: Path | str, mode: Optional[str] = None):
        self.checks = json.loads(Path(checks).read_text(encoding="utf-8")) if Path(checks).exists() else {}
        self.th = {"inbound": 0.7, "outbound": 0.5, **(self.checks.get("thresholds") or {})}
        mode = (mode or os.environ.get("BLVK_GUARD") or "auto").lower()
        self.router = None
        self.mode = "rules"
        if mode in ("auto", "laya"):
            try:
                from laya import Router
                self.router = Router()
                self.mode = "laya+rules"
            except Exception as exc:
                if mode == "laya":
                    raise RuntimeError(f"Laya requested but not available: {exc}") from exc

    def _laya(self, text: str, questions: dict) -> dict:
        if not self.router or not questions:
            return {}
        try:
            out = self.router.predict(text, questions)["answers"]
        except Exception:
            return {}
        probs = {}
        for name, a in out.items():
            if a.get("type") == "noul":
                probs[name] = float(a["noul"])
            elif a.get("type") == "choice":
                probs[name] = {"choice": a["choice"], "confidence": float(a.get("answer_confidence", 0))}
        return probs

    def check_inbound(self, text: str) -> dict:
        """Flags for a customer's message: injection, opt_out, wants_person, upset."""
        flags, reasons = [], []
        explicit = bool(_any(OPT_OUT_EXPLICIT, text))
        rules = {"injection": _any(INJECTION, text), "opt_out": explicit, "wants_person": _any(WANTS_PERSON, text),
                 "upset": _any(UPSET, text)}
        probs = self._laya(text, self.checks.get("inbound", {}))
        for key in ("injection", "opt_out", "wants_person", "upset"):
            p = probs.get(key)
            if rules[key] or (isinstance(p, float) and p >= self.th["inbound"]):
                flags.append(key)
                reasons.append(f"{key} ({'rule' if rules[key] else f'laya {p:.2f}'})")
        return {"flags": flags, "reasons": reasons, "opt_out_explicit": explicit,
                "scores": {k: v for k, v in probs.items() if isinstance(v, float)}, "mode": self.mode}

    def check_outbound(self, text: str) -> dict:
        """Flags for a draft a customer would read: commitments and the owner's never-do rules."""
        reasons = []
        hits = _any(COMMITMENT, text)
        if hits:
            reasons.append("names a price, discount, refund, date or time: check it is written down and confirmed")
        qs = dict(self.checks.get("outbound", {}))
        probs = self._laya(text, qs)
        p = probs.get("commitment")
        if isinstance(p, float) and p >= self.th["outbound"] and not hits:
            reasons.append(f"may promise a price, date or time (laya {p:.2f})")
        rules = self.checks.get("never_rules", {})
        for key, rule in rules.items():
            q = probs.get(key)
            if isinstance(q, float) and q >= self.th["outbound"]:
                reasons.append(f"may break the rule \"{rule}\" (laya {q:.2f})")
        return {"flagged": bool(reasons), "reasons": reasons, "mode": self.mode,
                "never_rules_checked": bool(rules) and self.router is not None}


def evaluate(guard: "Guard", path: Path) -> dict:
    """Score the guard on your own labelled examples, one JSON object per line:

        {"direction": "in",  "text": "please stop texting me", "expect": ["opt_out"]}
        {"direction": "out", "text": "We can do Tuesday at 2pm", "expect": ["flag"]}
        {"direction": "out", "text": "Thanks, talk soon", "expect": []}

    For "in", expect lists the flags that should fire (injection, opt_out,
    wants_person, upset). For "out", expect is ["flag"] when the draft should be
    held and [] when it should not. Prints what it got wrong, so you can raise or
    lower the thresholds in guards/checks.json on evidence, not guesses."""
    rows = [json.loads(line) for line in Path(path).read_text(encoding="utf-8").splitlines() if line.strip()]
    right, wrong, misses, alarms = 0, [], 0, 0
    for row in rows:
        if row.get("direction") == "out":
            got = ["flag"] if guard.check_outbound(row["text"])["flagged"] else []
        else:
            got = guard.check_inbound(row["text"])["flags"]
        want = set(row.get("expect") or [])
        if set(got) == want:
            right += 1
        else:
            misses += len(want - set(got))
            alarms += len(set(got) - want)
            wrong.append({"text": row["text"][:120], "expected": sorted(want), "got": sorted(got)})
    return {"examples": len(rows), "all_right": right, "missed_flags": misses, "false_alarms": alarms,
            "mode": guard.mode, "wrong": wrong}


if __name__ == "__main__":
    import sys
    g = Guard(Path(__file__).resolve().parent.parent / "guards" / "checks.json")
    if sys.argv[1:2] == ["eval"] and len(sys.argv) > 2:
        print(json.dumps(evaluate(g, Path(sys.argv[2])), indent=2, ensure_ascii=False))
        sys.exit(0)
    text = " ".join(sys.argv[2:]) or sys.stdin.read()
    print(json.dumps(g.check_outbound(text) if sys.argv[1:2] == ["out"] else g.check_inbound(text), indent=2))
