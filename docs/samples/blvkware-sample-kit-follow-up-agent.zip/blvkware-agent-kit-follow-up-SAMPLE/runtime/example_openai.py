"""The whole loop with OpenAI Chat Completions: model -> runtime -> your systems.

    pip install openai
    set OPENAI_API_KEY=...  and  set OPENAI_MODEL=<a model that supports tool calling>
    python runtime/example_openai.py "Hi, any update on my quote?" customer@example.com

Replace the example handler with calls to your own systems, and register one
for every tool in tools/tools.json your agent uses.
"""
from __future__ import annotations

import json
import os
import sys

from openai import OpenAI

from blvk_runtime import KIT, Runtime

rt = Runtime()


def email_send(args):  # example: replace with your email provider
    return {"sent": True}


if "email_send" in rt.tools:
    rt.register("email_send", email_send)


SYSTEM = (KIT / "prompts" / "system.md").read_text(encoding="utf-8")
TOOLS = json.loads((KIT / "tools" / "openai.json").read_text(encoding="utf-8"))
MODEL = os.environ["OPENAI_MODEL"]


def handle(message: str, contact: str | None = None) -> str:
    client = OpenAI()
    verdict = rt.inspect_inbound(message, contact)
    if contact and rt.is_suppressed(contact):
        return "(opted out: nothing sent)"
    messages = [{"role": "system", "content": SYSTEM}, {"role": "user", "content": rt.wrap_inbound(message, verdict)}]
    for _ in range(12):
        resp = client.chat.completions.create(model=MODEL, messages=messages, tools=TOOLS)
        msg = resp.choices[0].message
        messages.append(msg)
        if not msg.tool_calls:
            return msg.content or ""
        for call in msg.tool_calls:
            try:
                args = json.loads(call.function.arguments or "{}")
            except json.JSONDecodeError:
                args = None
            r = rt.call(call.function.name, args if isinstance(args, dict) else {"_invalid": True})
            messages.append({"role": "tool", "tool_call_id": call.id, "content": r.for_model()})
    rt.call("agent_escalate", {"reason": "the agent did not finish in 12 steps", "summary": message[:500], "urgency": "today"})
    return "(handed to a person)"


if __name__ == "__main__":
    print(handle(sys.argv[1] if len(sys.argv) > 1 else "Hello", sys.argv[2] if len(sys.argv) > 2 else None))
    for r in rt.run_due():
        print("carried out:", r.as_dict())
