"""The whole loop with Anthropic's Messages API: model -> runtime -> your systems.

    pip install anthropic
    set ANTHROPIC_API_KEY=...            (never put keys in these files)
    python runtime/example_anthropic.py "Hi, any update on my quote?" customer@example.com

Replace the two example handlers with calls to your own systems, and register
one for every tool in tools/tools.json your agent uses. A tool without a
handler fails safely: the model is told it did not happen.
"""
from __future__ import annotations

import json
import os
import sys

import anthropic

from blvk_runtime import KIT, Runtime

rt = Runtime()


def crm_get(args):  # example: replace with a call to your CRM
    return {"id": args["record_id"], "note": "replace this handler with your CRM lookup"} if "record_id" in args else {}


if "crm_get" in rt.tools:
    rt.register("crm_get", crm_get)


def email_send(args):  # example: replace with your email provider
    return {"sent": True}


if "email_send" in rt.tools:
    rt.register("email_send", email_send)


SYSTEM = (KIT / "prompts" / "system.md").read_text(encoding="utf-8")
TOOLS = json.loads((KIT / "tools" / "anthropic.json").read_text(encoding="utf-8"))
MODEL = os.environ.get("BLVK_MODEL", "claude-sonnet-5")


def handle(message: str, contact: str | None = None) -> str:
    client = anthropic.Anthropic()
    verdict = rt.inspect_inbound(message, contact)          # opt-outs, injected instructions, wants a person
    if contact and rt.is_suppressed(contact):
        return "(opted out: nothing sent)"
    messages = [{"role": "user", "content": rt.wrap_inbound(message, verdict)}]
    for _ in range(12):                                     # bounded: an agent loop must always end
        resp = client.messages.create(model=MODEL, max_tokens=2048, system=SYSTEM, tools=TOOLS, messages=messages)
        messages.append({"role": "assistant", "content": resp.content})
        if resp.stop_reason != "tool_use":
            return "".join(b.text for b in resp.content if b.type == "text")
        results = []
        for block in resp.content:
            if block.type == "tool_use":
                r = rt.call(block.name, block.input)       # every rule is enforced here
                results.append({"type": "tool_result", "tool_use_id": block.id, "content": r.for_model(),
                                "is_error": r.status in ("refused", "failed")})
        messages.append({"role": "user", "content": results})
    rt.call("agent_escalate", {"reason": "the agent did not finish in 12 steps", "summary": message[:500], "urgency": "today"})
    return "(handed to a person)"


if __name__ == "__main__":
    print(handle(sys.argv[1] if len(sys.argv) > 1 else "Hello", sys.argv[2] if len(sys.argv) > 2 else None))
    for r in rt.run_due():                                  # approved actions and deferred sends; run this every minute
        print("carried out:", r.as_dict())
