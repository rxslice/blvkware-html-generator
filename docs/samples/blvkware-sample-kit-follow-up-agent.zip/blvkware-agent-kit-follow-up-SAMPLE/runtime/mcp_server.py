"""This agent's tools as an MCP server, with every call going through the runtime.

Connect it to Claude Desktop, Claude Code, or any MCP client, and the model can
use your agent's tools while the rules still hold: held actions wait on the
approvals page, opt-outs and quiet hours apply, everything is logged.

    python runtime/mcp_server.py            (the client starts it; stdio)

Claude Desktop, in claude_desktop_config.json:

    {"mcpServers": {"my-agent": {"command": "python",
        "args": ["C:/path/to/kit/runtime/mcp_server.py"],
        "env": {"BLVK_TIMEZONE": "America/Chicago"}}}}

Claude Code: claude mcp add my-agent -- python /path/to/kit/runtime/mcp_server.py

The system prompt is offered as the MCP prompt "system", so a client can load
the agent's instructions too. Standard library only: MCP over stdio is
newline-delimited JSON-RPC 2.0, implemented here directly.
"""
from __future__ import annotations

import json
import sys
import traceback
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from blvk_runtime import Runtime  # noqa: E402

SUPPORTED = ("2025-06-18", "2025-03-26", "2024-11-05")


class Server:
    def __init__(self, rt: Runtime):
        self.rt = rt
        catalog = json.loads((rt.kit / "tools" / "mcp.json").read_text(encoding="utf-8"))
        self.tools = catalog["tools"]
        role = rt.manifest.get("role", {}).get("name", "Agent")
        self.name = "blvkware-" + "".join(c if c.isalnum() else "-" for c in role.lower()).strip("-")
        self.system = (rt.kit / "prompts" / "system.md").read_text(encoding="utf-8")

    def handle(self, msg: dict):
        method, mid, params = msg.get("method"), msg.get("id"), msg.get("params") or {}
        if mid is None:  # a notification: nothing to answer
            return None
        try:
            result = self.dispatch(method, params)
        except KeyError as exc:
            return {"jsonrpc": "2.0", "id": mid, "error": {"code": -32602, "message": f"missing {exc}"}}
        except LookupError:
            return {"jsonrpc": "2.0", "id": mid, "error": {"code": -32601, "message": f"unknown method {method}"}}
        except Exception as exc:  # never crash the client's session
            traceback.print_exc(file=sys.stderr)
            return {"jsonrpc": "2.0", "id": mid, "error": {"code": -32603, "message": f"{type(exc).__name__}: {exc}"}}
        return {"jsonrpc": "2.0", "id": mid, "result": result}

    def dispatch(self, method: str, params: dict) -> dict:
        if method == "initialize":
            asked = params.get("protocolVersion")
            return {"protocolVersion": asked if asked in SUPPORTED else SUPPORTED[0],
                    "capabilities": {"tools": {"listChanged": False}, "prompts": {"listChanged": False}},
                    "serverInfo": {"name": self.name, "version": "1.0"},
                    "instructions": "Tools of a BlvkWare agent. Every call passes through its runtime: actions that reach "
                                    "customers or money may be held for a person, and a held action has NOT happened."}
        if method == "ping":
            return {}
        if method == "tools/list":
            return {"tools": self.tools}
        if method == "tools/call":
            name, args = params["name"], params.get("arguments") or {}
            r = self.rt.call(name, args)
            self.rt.run_due()  # anything approved on the approvals page since the last call
            return {"content": [{"type": "text", "text": r.for_model()}], "isError": r.status in ("refused", "failed")}
        if method == "prompts/list":
            return {"prompts": [{"name": "system", "description": "The agent's instructions, with the owner's rules."}]}
        if method == "prompts/get":
            if params.get("name") != "system":
                raise KeyError("prompt name 'system'")
            return {"description": "The agent's instructions",
                    "messages": [{"role": "user", "content": {"type": "text", "text": self.system}}]}
        raise LookupError(method)


def serve(rt: Runtime, stdin=sys.stdin, stdout=sys.stdout) -> None:
    server = Server(rt)
    for line in stdin:
        line = line.strip()
        if not line:
            continue
        try:
            msg = json.loads(line)
        except json.JSONDecodeError:
            out = {"jsonrpc": "2.0", "id": None, "error": {"code": -32700, "message": "parse error"}}
        else:
            out = server.handle(msg) if isinstance(msg, dict) else None
        if out is not None:
            stdout.write(json.dumps(out, ensure_ascii=False, default=str) + "\n")
            stdout.flush()


def main() -> int:
    for stream in (sys.stdin, sys.stdout):
        try:
            stream.reconfigure(encoding="utf-8", newline="\n")
        except Exception:
            pass
    rt = Runtime()
    try:
        from handlers import register_all
        register_all(rt)
    except Exception as exc:
        print(f"[mcp_server] handlers not loaded: {exc}", file=sys.stderr)
    for w in rt.warnings:
        print(f"[mcp_server] {w}", file=sys.stderr)
    serve(rt)
    return 0


if __name__ == "__main__":
    sys.exit(main())
