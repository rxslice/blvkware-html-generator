# Sample licence

This is a sample kit, generated for a fictional business (Harbor Plumbing & Drain) to show what a BlvkWare kit contains.

You may read it, share it and link to it. It is not licensed for use in a business, and it is not designed for yours: its instructions, rules and systems are Harbor's.

A kit for your own business is generated from your answers at https://blvkware.dev/hire/ and comes with a licence to use it.
